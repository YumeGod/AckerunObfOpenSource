package cn.AckerRun.Ackerobfuscator.utils.configuration.serialization;

import java.util.*;

public interface ConfigurationSerializable
{
    Map<String, Object> serialize();
}
