package cn.AckerRun.Ackerobfuscator.addons;

import java.io.*;
import java.util.*;

public interface IObfuscator
{
    void transform(final File p0, final File p1, final List<File> p2);
}
